return {
	{'nvim-lua/plenary.nvim'},
	{
		'junegunn/fzf',
		dir='~/.fzf', 
		build='./install --all'
	},
	{'junegunn/fzf.vim'},
}
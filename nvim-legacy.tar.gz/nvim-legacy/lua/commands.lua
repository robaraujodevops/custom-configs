vim.cmd [[syntax on]]
vim.cmd [[highlight Normal guibg=none]]
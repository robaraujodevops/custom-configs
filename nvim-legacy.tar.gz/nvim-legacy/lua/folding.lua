vim.o.foldmethod="indent"
vim.o.nofoldenable=true
vim.keymap.set('n', '<leader>z', 'za<cr>', { remap = true, silent = true })

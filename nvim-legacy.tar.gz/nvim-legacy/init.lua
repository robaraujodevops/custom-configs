require("options")
require("functions")
require("commands")
require("lazyconfig")
require("autocommands")
package.loaded['keymaps'] = nil
require("keymaps")
